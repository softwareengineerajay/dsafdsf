==============================================
Instructions for use
==============================================

For API Developers 
To validate your APiDefinition files we suggest you use :
	https://www.jsonschemavalidator.net/
	
To validate in Visual Studio Code	
see the following guide:
	https://code.visualstudio.com/docs/languages/json
	
e.g.
Edit the file in C:\Users<user>\AppData\Roaming\Code\User\settings.json

Add
{
	"fileMatch": [
	"*-definition.json"
],
	"url": "file:///source/apihub--apihub--apimdefinitionfiles/Schema/apidefinition-schema-v1.0.json"
}	
	
	
==============================================	
*** Do not change the attached schema ***
Contact the ApiHub team if you require changes
==============================================
